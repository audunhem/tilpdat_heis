#include <pthread.h>
#include <stdio.h>

 int i; 
pthread_mutex_t count_mutex;
// Note the return type: void*
void* Thread1Function(){
    int j;
    for (j=0; j<1000000; j++){
        pthread_mutex_lock(&count_mutex); 
    	i++;
        
    
        pthread_mutex_unlock(&count_mutex);

    } 
    return NULL;
}

void* Thread2Function(){
    int j;
    for (j=0; j<1000000; j++){
        pthread_mutex_lock(&count_mutex);
    	i--;
        
    	
        pthread_mutex_unlock(&count_mutex);

    } 

    return NULL;
}

int main(){
    pthread_t someThread1, someThread2;
    pthread_create(&someThread1, NULL, Thread1Function, NULL);
    
    pthread_create(&someThread2, NULL, Thread2Function, NULL);

    // Arguments to a thread would be passed here ---------^
    
    pthread_join(someThread1, NULL);
    pthread_join(someThread2, NULL);
    
    printf("%d\n",i);
    pthread_mutex_destroy(&count_mutex);
    return 0;
    
}