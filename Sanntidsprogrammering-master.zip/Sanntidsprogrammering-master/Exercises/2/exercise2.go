// Go 1.2
// go run helloworld_go.go

package main

import (
    . "fmt"
    "runtime"
    "time"
)

var i int


func thread1(c chan int) {
    
    for j:= 0; j<100000; j++{
        <-c
        i++
        c <- 1
    }
  

}

func thread2(c chan int) {
    
    for j:= 0; j<100000; j++{
        <-c
        i--
        c <- 1
    }
    
}

func main() {
    runtime.GOMAXPROCS(runtime.NumCPU())    // I guess this is a hint to what GOMAXPROCS does...
    i=0
    c := make(chan int, 1)                                        // Try doing the exercise both with and without it!
    c <- 1
    go thread1(c)
    go thread2(c)
                    // This spawns someGoroutine() as a goroutine
    
    // We have no way to wait for the completion of a goroutine (without additional syncronization of some sort)
    // We'll come back to using channels in Exercise 2. For now: Sleep.
    time.Sleep(100*time.Millisecond)
    Println(i)
}