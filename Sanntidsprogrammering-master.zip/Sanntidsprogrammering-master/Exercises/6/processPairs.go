package main

import(
	"log"
	"net"
	"time"
	"encoding/binary"
	"os/exec"
)

func primaryProcess(startCount int, udpBroadcast *net.UDPConn){

	// Setting up new backup process in separate terminal
	newBackup := exec.Command("gnome-terminal", "-x", "sh", "-c", "go run processPairs.go")
	err := newBackup.Run()
	if err != nil {log.Fatal(err)}

	msg := make([]byte, 1)

	// Count and broadcast number. 
	for i := startCount; ; i++{
		log.Println(i)
		msg[0] = byte(i);
		udpBroadcast.Write(msg)
		time.Sleep(100*time.Millisecond)
	}
	
}

func backupProcess(udpListen *net.UDPConn) int{
	listenChan := make(chan int, 1); 
	backupvalue := 0

	// Start listen as separate goroutine
	go listen(listenChan, udpListen)

	// Select waits for one case, then sleeps. Listen then runs.
	for {
		select {
			case backupvalue = <- listenChan:
				time.Sleep(50*time.Millisecond)
				break
			case <-time.After(1*time.Second):
				if backupvalue > 0 {
					log.Println("Primary failed. Taking over counting.")
				}
				return backupvalue
		}
	}
	
	
}

func listen(listenChan chan int, udpListen *net.UDPConn) {

	buffer := make([]byte, 1024)

	for {
		udpListen.ReadFromUDP(buffer[:])
		//if err != nil {log.Fatal(err)} 
		
		listenChan <- int(binary.LittleEndian.Uint64(buffer)) // Converting bytearray to int
		time.Sleep(100*time.Millisecond)
	}
	
}

func main() {
	
	// Initiating UDP address for backup process
	udpAddr, err := net.ResolveUDPAddr("udp", "localhost:20000")
	if err != nil {log.Fatal(err)}

	// Backup listening to primary
	udpListen, err := net.ListenUDP("udp", udpAddr)
	if err != nil {log.Fatal(err)}
	
	// Last number retreived from primary
	currentCount := backupProcess(udpListen)
	
	// Backup taking over as primary. Closing listening connection.
	udpListen.Close()
	
	// Initiating UDP address for primary process.
	udpAddr, err = net.ResolveUDPAddr("udp","localhost:20000")
	if err != nil {log.Fatal(err)}

	// Setting up connection to backup.
	udpBroadcast, err := net.DialUDP("udp", nil, udpAddr)
	if err != nil {log.Fatal(err)}
	
	// Starting primary process
	primaryProcess(currentCount + 1, udpBroadcast)
	
	// Closing UDP connection when primary process fails.
	udpBroadcast.Close()
	
	
}
