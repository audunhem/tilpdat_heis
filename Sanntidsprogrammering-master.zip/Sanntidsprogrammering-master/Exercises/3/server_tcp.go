package main 

import "net" 
import "fmt" 
import "bufio" 
import "os"

func main() {

  fmt.Println("Launching server...")

  conn, _ := net.Dial("tcp", "129.241.187.23:33546")
  fmt.Fprintf(conn, "Connect to: 129.241.187.154:20007\x00")



  // listen on all interfaces
  ln, _ := net.Listen("tcp", ":20007")

  // accept connection on port
  conn, _ = ln.Accept()

  fmt.Println("Connection accepted...")

  // run loop forever (or until ctrl-c)


  for {
    // read in input from stdin
    reader := bufio.NewReader(os.Stdin)
    fmt.Print("\nText to send: ")
    text, _ := reader.ReadString('\n')
    // send to socket
    fmt.Fprintf(conn, text+"\x00")
    // listen for reply
    message, _ := bufio.NewReader(conn).ReadString('\n')
    fmt.Print("Message from server: " + message)
  }

  // for {
  //   // will listen for message to process ending in newline (\n)

  //   fmt.Println("Listening for messages...")

  //   message, _ := bufio.NewReader(conn).ReadString('\n')
  //   // output message received
  //   fmt.Print("Message Received:", string(message))
  //   // sample process for string received
  //   newmessage := strings.ToUpper(message)
  //   // send new string back to client
  //   conn.Write([]byte(newmessage + "\n"))
  // }

} 