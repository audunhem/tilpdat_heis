
# Python 3.3.3 and 2.7.6
# python helloworld_python.py

from threading import Thread

i = 0

def ThreadFunction1():
    global i
    for x in range(0,1000):
    	i+=1

def ThreadFunction2():
    global i
    for x in range(0,1000):
    	i-=1

def main():
    global i
    Thread1 = Thread(target = ThreadFunction1, args = (),)
    Thread1.start()
    
    Thread2 = Thread(target = ThreadFunction2, args = (),)
    Thread2.start()
    
    Thread1.join()
    Thread2.join()
    print(i)


main()