// gcc 4.7.2 +
// gcc -std=gnu99 -Wall -g -o helloworld_c helloworld_c.c -lpthread

#include <pthread.h>
#include <stdio.h>
 int i; 

// Note the return type: void*
void* Thread1Function(){
    int j;
    for (j=0; j<10; j++){
    	i++;
    	printf("hello 1\n");
    } 
    return NULL;
}

void* Thread2Function(){
    int j;
    for (j=0; j<10; j++){
    	i--;
    	printf("hello 2\n");
    } 

    return NULL;
}

int main(){
    pthread_t someThread1;
    pthread_create(&someThread1, NULL, Thread1Function, NULL);
    pthread_t someThread2;
    pthread_create(&someThread2, NULL, Thread2Function, NULL);

    // Arguments to a thread would be passed here ---------^
    
    pthread_join(someThread1, NULL);
    pthread_join(someThread2, NULL);
    
    printf("%d\n",i);
    return 0;
    
}